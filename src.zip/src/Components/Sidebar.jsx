
import {
  FiHome,
  FiUsers,
  FiCheckSquare,
  FiFileText,
  FiBarChart2,
  FiSettings,
  FiCamera,
} from "react-icons/fi";

import { NavLink } from "react-router-dom";

function Sidebar() {
  const menuItems = [
    {
      name: "Dashboard",
      path: "/",
      icon: <FiHome />,
    },
    {
      name: "Students",
      path: "/students",
      icon: <FiUsers />,
    },
    {
      name: "Attendance",
      path: "#",
      icon: <FiCheckSquare />,
    },
    {
      name: "Reports",
      path: "#",
      icon: <FiFileText />,
    },
    {
      name: "Analytics",
      path: "#",
      icon: <FiBarChart2 />,
    },
  ];

  return (
    <aside className="hidden md:flex w-64 bg-white border-r border-gray-200 min-h-screen flex-col">

      {/* Logo */}
      <div className="h-20 flex items-center px-6 border-b border-gray-200">

        <div className="flex items-center gap-3">

          <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
            <FiCamera className="text-white text-xl" />
          </div>

          <h1 className="text-xl font-bold text-gray-800">
            SmartAttend
          </h1>

        </div>

      </div>

      {/* Navigation */}
      <nav className="flex-1 px-4 py-6">

        <p className="text-xs font-semibold text-gray-400 uppercase mb-3 px-3">
          Main Menu
        </p>

        <div className="space-y-1">

          {menuItems.map((item) => (

            <NavLink
              key={item.name}
              to={item.path}
              className={({ isActive }) =>
                `flex items-center gap-3 px-3 py-3 rounded-lg transition ${
                  isActive
                    ? "bg-blue-50 text-blue-600 font-medium"
                    : "text-gray-600 hover:bg-gray-50 hover:text-blue-600"
                }`
              }
            >

              <span className="text-lg">
                {item.icon}
              </span>

              <span>
                {item.name}
              </span>

            </NavLink>

          ))}

        </div>

        <p className="text-xs font-semibold text-gray-400 uppercase mt-8 mb-3 px-3">
          System
        </p>

        <a
          href="#"
          className="flex items-center gap-3 px-3 py-3 rounded-lg text-gray-600 hover:bg-gray-50 hover:text-blue-600 transition"
        >

          <FiSettings className="text-lg" />

          <span>
            Settings
          </span>

        </a>

      </nav>

      {/* Footer */}
      <div className="p-4 border-t border-gray-200">

        <div className="bg-blue-50 rounded-lg p-4">

          <p className="text-sm font-semibold text-blue-700">
            Smart Attendance
          </p>

          <p className="text-xs text-blue-500 mt-1">
            AI Face Recognition System
          </p>

        </div>

      </div>

    </aside>
  );
}

export default Sidebar;

