import {
  FiUsers,
  FiCheckCircle,
  FiXCircle,
  FiCalendar,
} from "react-icons/fi";

const Dashboard = () => {
  const stats = [
    {
      title: "Total Students",
      value: "120",
      icon: <FiUsers />,
      description: "Registered students",
    },
    {
      title: "Present Today",
      value: "98",
      icon: <FiCheckCircle />,
      description: "Students present",
    },
    {
      title: "Absent Today",
      value: "22",
      icon: <FiXCircle />,
      description: "Students absent",
    },
    {
      title: "Attendance Rate",
      value: "81.6%",
      icon: <FiCalendar />,
      description: "Today's attendance",
    },
  ];

  const attendanceData = [
    { day: "Mon", present: 85, absent: 15 },
    { day: "Tue", present: 92, absent: 8 },
    { day: "Wed", present: 78, absent: 22 },
    { day: "Thu", present: 95, absent: 5 },
    { day: "Fri", present: 88, absent: 12 },
    { day: "Sat", present: 70, absent: 30 },
  ];

  return (
    <div className="min-h-screen bg-slate-50 p-6">

      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-slate-800">
          Dashboard
        </h1>

        <p className="mt-1 text-slate-500">
          Welcome back, Admin 👋
        </p>
      </div>

      {/* Statistics */}
      <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">

        {stats.map((stat, index) => (
          <div
            key={index}
            className="rounded-2xl bg-white p-5 shadow-sm"
          >
            <div className="flex items-center justify-between">

              <div>
                <p className="text-sm font-medium text-slate-500">
                  {stat.title}
                </p>

                <h2 className="mt-2 text-3xl font-bold text-slate-800">
                  {stat.value}
                </h2>

                <p className="mt-1 text-xs text-slate-400">
                  {stat.description}
                </p>
              </div>

              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-blue-50 text-xl text-blue-600">
                {stat.icon}
              </div>

            </div>
          </div>
        ))}

      </div>

      {/* Content */}
      <div className="mt-6 grid grid-cols-1 gap-6 lg:grid-cols-2">

        {/* Attendance Chart */}
        <div className="rounded-2xl bg-white p-6 shadow-sm">

          <div className="mb-6">
            <h2 className="text-lg font-semibold text-slate-800">
              Attendance Overview
            </h2>

            <p className="text-sm text-slate-400">
              Weekly attendance statistics
            </p>
          </div>

          {/* Chart */}
          <div className="rounded-xl bg-slate-50 p-5">

            <div className="flex h-56 items-end justify-between gap-3">

              {attendanceData.map((item, index) => (
                <div
                  key={index}
                  className="flex h-full flex-1 flex-col items-center justify-end"
                >

                  {/* Bars */}
                  <div className="flex h-48 w-full max-w-12 items-end justify-center gap-1">

                    {/* Present */}
                    <div
                      className="w-1/2 rounded-t-md bg-blue-500 transition-all hover:bg-blue-600"
                      style={{
                        height: `${item.present}%`,
                      }}
                      title={`Present: ${item.present}%`}
                    ></div>

                    {/* Absent */}
                    <div
                      className="w-1/2 rounded-t-md bg-red-300 transition-all hover:bg-red-400"
                      style={{
                        height: `${item.absent}%`,
                      }}
                      title={`Absent: ${item.absent}%`}
                    ></div>

                  </div>

                  {/* Day */}
                  <p className="mt-3 text-xs font-medium text-slate-500">
                    {item.day}
                  </p>

                </div>
              ))}

            </div>

            {/* Legend */}
            <div className="mt-5 flex items-center justify-center gap-6 border-t border-slate-200 pt-4">

              <div className="flex items-center gap-2">
                <span className="h-3 w-3 rounded-full bg-blue-500"></span>

                <span className="text-xs text-slate-500">
                  Present
                </span>
              </div>

              <div className="flex items-center gap-2">
                <span className="h-3 w-3 rounded-full bg-red-300"></span>

                <span className="text-xs text-slate-500">
                  Absent
                </span>
              </div>

            </div>

          </div>

        </div>

        {/* Recent Attendance */}
        <div className="rounded-2xl bg-white p-6 shadow-sm">

          <div className="mb-6">
            <h2 className="text-lg font-semibold text-slate-800">
              Recent Attendance
            </h2>

            <p className="text-sm text-slate-400">
              Today's latest records
            </p>
          </div>

          <div className="space-y-4">

            {[
              ["Ali Ahmed", "09:05 AM", "Present"],
              ["Ahmed Khan", "09:08 AM", "Present"],
              ["Usman Ali", "09:15 AM", "Present"],
              ["Hassan Raza", "—", "Absent"],
            ].map((student, index) => (

              <div
                key={index}
                className="flex items-center justify-between border-b border-slate-100 pb-3"
              >

                <div>
                  <p className="font-medium text-slate-700">
                    {student[0]}
                  </p>

                  <p className="text-xs text-slate-400">
                    {student[1]}
                  </p>
                </div>

                <span
                  className={`rounded-full px-3 py-1 text-xs font-medium ${
                    student[2] === "Present"
                      ? "bg-green-50 text-green-600"
                      : "bg-red-50 text-red-600"
                  }`}
                >
                  {student[2]}
                </span>

              </div>

            ))}

          </div>

        </div>

      </div>

    </div>
  );
};

export default Dashboard;