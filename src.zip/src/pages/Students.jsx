import { useRef, useState } from "react";

import Sidebar from "../Components/Sidebar";
// import Topbar from "../Components/Topbar";

import {
  FiPlus,
  FiSearch,
  FiEdit2,
  FiTrash2,
  FiCamera,
  FiX,
  FiCheck,
  FiUser,
} from "react-icons/fi";

function Students() {

  const [students, setStudents] = useState([
    {
      id: 1,
      studentId: "ST-001",
      name: "Ali Hassan",
      email: "ali@example.com",
      className: "BSCS-7A",
      phone: "0300-1234567",
      status: "Active",
      faceRegistered: true,
    },
    {
      id: 2,
      studentId: "ST-002",
      name: "Ahmed Raza",
      email: "ahmed@example.com",
      className: "BSCS-7A",
      phone: "0301-7654321",
      status: "Active",
      faceRegistered: true,
    },
    {
      id: 3,
      studentId: "ST-003",
      name: "Usman Khan",
      email: "usman@example.com",
      className: "BSCS-7B",
      phone: "0302-9876543",
      status: "Active",
      faceRegistered: false,
    },
    {
      id: 4,
      studentId: "ST-004",
      name: "Hassan Ali",
      email: "hassan@example.com",
      className: "BSCS-7B",
      phone: "0303-4567890",
      status: "Inactive",
      faceRegistered: false,
    },
  ]);

  const [search, setSearch] = useState("");

  const [showModal, setShowModal] = useState(false);

  const [editingStudent, setEditingStudent] = useState(null);

  const [showCamera, setShowCamera] = useState(false);

  const [capturedImage, setCapturedImage] = useState(null);

  const videoRef = useRef(null);

  const streamRef = useRef(null);

  const [formData, setFormData] = useState({
    studentId: "",
    name: "",
    email: "",
    className: "",
    phone: "",
  });

  // Search
  const filteredStudents = students.filter((student) => {

    const value = search.toLowerCase();

    return (
      student.name.toLowerCase().includes(value) ||
      student.studentId.toLowerCase().includes(value) ||
      student.className.toLowerCase().includes(value)
    );

  });

  // Open Add Student
  const openAddModal = () => {

    setEditingStudent(null);

    setFormData({
      studentId: "",
      name: "",
      email: "",
      className: "",
      phone: "",
    });

    setCapturedImage(null);

    setShowModal(true);
  };

  // Open Edit Student
  const openEditModal = (student) => {

    setEditingStudent(student);

    setFormData({
      studentId: student.studentId,
      name: student.name,
      email: student.email,
      className: student.className,
      phone: student.phone,
    });

    setCapturedImage(null);

    setShowModal(true);
  };

  // Form change
  const handleChange = (e) => {

    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });

  };

  // Save Student
  const handleSubmit = (e) => {

    e.preventDefault();

    if (!formData.name || !formData.studentId || !formData.className) {
      alert("Please fill all required fields.");
      return;
    }

    if (editingStudent) {

      setStudents(
        students.map((student) =>
          student.id === editingStudent.id
            ? {
                ...student,
                ...formData,
                faceRegistered:
                  capturedImage
                    ? true
                    : student.faceRegistered,
              }
            : student
        )
      );

    } else {

      const newStudent = {
        id: Date.now(),
        ...formData,
        status: "Active",
        faceRegistered: Boolean(capturedImage),
      };

      setStudents([
        ...students,
        newStudent,
      ]);

    }

    setShowModal(false);
  };

  // Delete
  const deleteStudent = (id) => {

    const confirmDelete = window.confirm(
      "Are you sure you want to delete this student?"
    );

    if (!confirmDelete) return;

    setStudents(
      students.filter(
        (student) => student.id !== id
      )
    );

  };

  // Start camera
  const startCamera = async () => {

    try {

      const stream =
        await navigator.mediaDevices.getUserMedia({
          video: true,
          audio: false,
        });

      streamRef.current = stream;

      setShowCamera(true);

      setTimeout(() => {

        if (videoRef.current) {
          videoRef.current.srcObject = stream;
        }

      }, 100);

    } catch (error) {

      alert(
        "Camera access was denied or is not available."
      );

    }

  };

  // Capture face
  const captureFace = () => {

    const video = videoRef.current;

    if (!video) return;

    const canvas = document.createElement("canvas");

    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;

    const context = canvas.getContext("2d");

    context.drawImage(
      video,
      0,
      0,
      canvas.width,
      canvas.height
    );

    const image =
      canvas.toDataURL("image/png");

    setCapturedImage(image);

    stopCamera();

  };

  // Stop camera
  const stopCamera = () => {

    if (streamRef.current) {

      streamRef.current
        .getTracks()
        .forEach((track) => track.stop());

      streamRef.current = null;

    }

    setShowCamera(false);
  };

  return (
    <div className="min-h-screen bg-gray-100 flex">

      <Sidebar />

      <div className="flex-1 min-w-0">

        <Topbar />

        <main className="p-4 sm:p-6 lg:p-8">

          {/* Page Header */}
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">

            <div>

              <h1 className="text-2xl sm:text-3xl font-bold text-gray-800">
                Students
              </h1>

              <p className="text-gray-500 mt-1">
                Manage students and register their faces
              </p>

            </div>

            <button
              onClick={openAddModal}
              className="flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-5 py-3 rounded-lg font-medium transition"
            >

              <FiPlus />

              Add Student

            </button>

          </div>

          {/* Search */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4 mb-6">

            <div className="relative">

              <FiSearch className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" />

              <input
                type="text"
                placeholder="Search by student name, ID or class..."
                value={search}
                onChange={(e) =>
                  setSearch(e.target.value)
                }
                className="w-full pl-11 pr-4 py-3 border border-gray-200 rounded-lg outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />

            </div>

          </div>

          {/* Students Table */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">

            <div className="overflow-x-auto">

              <table className="w-full min-w-[850px]">

                <thead className="bg-gray-50">

                  <tr>

                    <th className="text-left px-6 py-4 text-xs font-semibold text-gray-500 uppercase">
                      Student
                    </th>

                    <th className="text-left px-6 py-4 text-xs font-semibold text-gray-500 uppercase">
                      Class
                    </th>

                    <th className="text-left px-6 py-4 text-xs font-semibold text-gray-500 uppercase">
                      Phone
                    </th>

                    <th className="text-left px-6 py-4 text-xs font-semibold text-gray-500 uppercase">
                      Face
                    </th>

                    <th className="text-left px-6 py-4 text-xs font-semibold text-gray-500 uppercase">
                      Status
                    </th>

                    <th className="text-right px-6 py-4 text-xs font-semibold text-gray-500 uppercase">
                      Actions
                    </th>

                  </tr>

                </thead>

                <tbody>

                  {filteredStudents.map((student) => (

                    <tr
                      key={student.id}
                      className="border-t border-gray-100 hover:bg-gray-50 transition"
                    >

                      {/* Student */}
                      <td className="px-6 py-4">

                        <div className="flex items-center gap-3">

                          <div className="w-10 h-10 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center font-semibold">
                            {student.name.charAt(0)}
                          </div>

                          <div>

                            <p className="font-medium text-gray-800">
                              {student.name}
                            </p>

                            <p className="text-xs text-gray-400">
                              {student.studentId}
                            </p>

                          </div>

                        </div>

                      </td>

                      {/* Class */}
                      <td className="px-6 py-4 text-sm text-gray-600">
                        {student.className}
                      </td>

                      {/* Phone */}
                      <td className="px-6 py-4 text-sm text-gray-600">
                        {student.phone}
                      </td>

                      {/* Face */}
                      <td className="px-6 py-4">

                        {student.faceRegistered ? (

                          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-green-100 text-green-700 text-xs font-medium">

                            <FiCheck />

                            Registered

                          </span>

                        ) : (

                          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-yellow-100 text-yellow-700 text-xs font-medium">

                            Not Registered

                          </span>

                        )}

                      </td>

                      {/* Status */}
                      <td className="px-6 py-4">

                        <span
                          className={`inline-flex px-2.5 py-1 rounded-full text-xs font-medium ${
                            student.status === "Active"
                              ? "bg-green-100 text-green-700"
                              : "bg-gray-100 text-gray-600"
                          }`}
                        >

                          {student.status}

                        </span>

                      </td>

                      {/* Actions */}
                      <td className="px-6 py-4">

                        <div className="flex justify-end gap-2">

                          <button
                            onClick={() =>
                              openEditModal(student)
                            }
                            className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg"
                            title="Edit"
                          >
                            <FiEdit2 />
                          </button>

                          <button
                            onClick={() =>
                              deleteStudent(student.id)
                            }
                            className="p-2 text-red-600 hover:bg-red-50 rounded-lg"
                            title="Delete"
                          >
                            <FiTrash2 />
                          </button>

                        </div>

                      </td>

                    </tr>

                  ))}

                </tbody>

              </table>

            </div>

            {filteredStudents.length === 0 && (

              <div className="text-center py-12">

                <FiUser className="mx-auto text-4xl text-gray-300 mb-3" />

                <p className="text-gray-500">
                  No students found
                </p>

              </div>

            )}

          </div>

        </main>

      </div>

      {/* Add/Edit Modal */}
      {showModal && (

        <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">

          <div className="bg-white rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">

            {/* Modal Header */}
            <div className="flex items-center justify-between px-6 py-5 border-b border-gray-100">

              <div>

                <h2 className="text-xl font-bold text-gray-800">

                  {editingStudent
                    ? "Edit Student"
                    : "Add New Student"}

                </h2>

                <p className="text-sm text-gray-500 mt-1">
                  Enter student information and register face
                </p>

              </div>

              <button
                onClick={() => {
                  stopCamera();
                  setShowModal(false);
                }}
                className="p-2 hover:bg-gray-100 rounded-lg text-gray-500"
              >

                <FiX className="text-xl" />

              </button>

            </div>

            {/* Form */}
            <form
              onSubmit={handleSubmit}
              className="p-6"
            >

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">

                {/* Student ID */}
                <div>

                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Student ID *
                  </label>

                  <input
                    name="studentId"
                    value={formData.studentId}
                    onChange={handleChange}
                    placeholder="ST-001"
                    className="w-full px-4 py-3 border border-gray-200 rounded-lg outline-none focus:ring-2 focus:ring-blue-500"
                    required
                  />

                </div>

                {/* Name */}
                <div>

                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Full Name *
                  </label>

                  <input
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    placeholder="Ali Hassan"
                    className="w-full px-4 py-3 border border-gray-200 rounded-lg outline-none focus:ring-2 focus:ring-blue-500"
                    required
                  />

                </div>

                {/* Email */}
                <div>

                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Email
                  </label>

                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    placeholder="student@example.com"
                    className="w-full px-4 py-3 border border-gray-200 rounded-lg outline-none focus:ring-2 focus:ring-blue-500"
                  />

                </div>

                {/* Class */}
                <div>

                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Class *
                  </label>

                  <select
                    name="className"
                    value={formData.className}
                    onChange={handleChange}
                    className="w-full px-4 py-3 border border-gray-200 rounded-lg outline-none focus:ring-2 focus:ring-blue-500 bg-white"
                    required
                  >

                    <option value="">
                      Select Class
                    </option>

                    <option value="BSCS-7A">
                      BSCS-7A
                    </option>

                    <option value="BSCS-7B">
                      BSCS-7B
                    </option>

                    <option value="BSCS-8A">
                      BSCS-8A
                    </option>

                    <option value="BSCS-8B">
                      BSCS-8B
                    </option>

                  </select>

                </div>

                {/* Phone */}
                <div className="sm:col-span-2">

                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Phone
                  </label>

                  <input
                    name="phone"
                    value={formData.phone}
                    onChange={handleChange}
                    placeholder="0300-1234567"
                    className="w-full px-4 py-3 border border-gray-200 rounded-lg outline-none focus:ring-2 focus:ring-blue-500"
                  />

                </div>

              </div>

              {/* Face Registration */}
              <div className="mt-6">

                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Face Registration
                </label>

                {!showCamera && !capturedImage && (

                  <div className="border-2 border-dashed border-gray-200 rounded-xl p-8 text-center">

                    <div className="w-14 h-14 mx-auto bg-blue-50 text-blue-600 rounded-full flex items-center justify-center mb-4">

                      <FiCamera className="text-2xl" />

                    </div>

                    <h3 className="font-semibold text-gray-800">
                      Register Student Face
                    </h3>

                    <p className="text-sm text-gray-500 mt-1 mb-4">
                      Use your camera to capture the student's face
                    </p>

                    <button
                      type="button"
                      onClick={startCamera}
                      className="inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-5 py-2.5 rounded-lg font-medium"
                    >

                      <FiCamera />

                      Open Camera

                    </button>

                  </div>

                )}

                {/* Camera */}
                {showCamera && (

                  <div className="rounded-xl overflow-hidden bg-black">

                    <div className="relative">

                      <video
                        ref={videoRef}
                        autoPlay
                        playsInline
                        className="w-full max-h-80 object-cover"
                      />

                      {/* Face Guide */}
                      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">

                        <div className="w-48 h-60 sm:w-56 sm:h-64 border-2 border-white rounded-[50%] opacity-80"></div>

                      </div>

                    </div>

                    <div className="p-4 flex justify-center gap-3">

                      <button
                        type="button"
                        onClick={captureFace}
                        className="flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white px-5 py-2.5 rounded-lg font-medium"
                      >

                        <FiCamera />

                        Capture Face

                      </button>

                      <button
                        type="button"
                        onClick={stopCamera}
                        className="px-5 py-2.5 bg-gray-700 hover:bg-gray-600 text-white rounded-lg"
                      >

                        Cancel

                      </button>

                    </div>

                  </div>

                )}

                {/* Captured Face */}
                {capturedImage && (

                  <div className="border border-green-200 bg-green-50 rounded-xl p-4">

                    <div className="flex flex-col sm:flex-row gap-4 items-center">

                      <img
                        src={capturedImage}
                        alt="Captured face"
                        className="w-32 h-32 object-cover rounded-xl"
                      />

                      <div className="flex-1 text-center sm:text-left">

                        <div className="flex items-center justify-center sm:justify-start gap-2 text-green-700 font-semibold">

                          <FiCheck />

                          Face Captured Successfully

                        </div>

                        <p className="text-sm text-gray-500 mt-1">
                          The face image is ready for registration.
                        </p>

                        <button
                          type="button"
                          onClick={() => {
                            setCapturedImage(null);
                            startCamera();
                          }}
                          className="mt-3 text-sm text-blue-600 font-medium"
                        >
                          Capture Again
                        </button>

                      </div>

                    </div>

                  </div>

                )}

              </div>

              {/* Buttons */}
              <div className="flex justify-end gap-3 mt-7 pt-5 border-t border-gray-100">

                <button
                  type="button"
                  onClick={() => {
                    stopCamera();
                    setShowModal(false);
                  }}
                  className="px-5 py-2.5 border border-gray-200 rounded-lg text-gray-600 hover:bg-gray-50"
                >
                  Cancel
                </button>

                <button
                  type="submit"
                  className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium"
                >

                  {editingStudent
                    ? "Update Student"
                    : "Save Student"}

                </button>

              </div>

            </form>

          </div>

        </div>

      )}

    </div>
  );
}

export default Students;
